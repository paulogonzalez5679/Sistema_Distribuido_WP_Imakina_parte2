<div>
	<date-picker v-model="date" lang="en" @change="dateChanged(date)"></date-picker>
</div>