<div>
    <slider-picker v-model="color"></slider-picker>
</div>