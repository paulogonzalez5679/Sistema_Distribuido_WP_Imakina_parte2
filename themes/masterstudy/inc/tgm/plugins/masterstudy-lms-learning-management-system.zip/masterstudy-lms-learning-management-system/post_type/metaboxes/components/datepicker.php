<div>
	<date-picker v-model="date" range lang="en" @change="dateChanged(date)"></date-picker>
</div>