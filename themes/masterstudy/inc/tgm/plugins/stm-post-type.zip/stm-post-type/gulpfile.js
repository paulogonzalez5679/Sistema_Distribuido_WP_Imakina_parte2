var gulp = require('gulp');
var lessToScss = require('gulp-less-to-scss');
var sass = require('gulp-sass');
var autoprefixer = require('gulp-autoprefixer');
const browserSync = require('browser-sync').create();
const watch = require('gulp-watch');
const cssmin = require('gulp-cssmin');
var sourcemaps = require('gulp-sourcemaps');
var cache = require('gulp-cached');
var livereload = require('gulp-livereload');
const babel = require('gulp-babel');
const cssbeautify = require('gulp-cssbeautify');

gulp.task('serve', function () {
    "use strict";
    browserSync.init({
        proxy: "http://lms.loc",
        host: "192.168.0.124",
        port: 3000,
        notify: true,
        ui: {
            port: 3001
        },
        open: false
    });
});

gulp.task('admin-css', () => {
    livereload.listen();

    admin_css();

    watch('./theme/assets/**/*.scss').on('change', (e) => {
        admin_css();
    });
});

function admin_css() {
    return gulp.src('./theme/assets/**/*.scss')
        .pipe(cache('admin-css'))
        .pipe(sass().on('error', sass.logError))
        .pipe(autoprefixer({
            browsers: ['last 4 versions'],
            cascade: false
        }))
        .pipe(gulp.dest('./theme/assets/'))
        .pipe(livereload())
        .pipe(browserSync.stream());
}

gulp.task('default', ['serve', 'admin-css']);