<?php if ( is_active_sidebar( 'shop' ) ) { ?>

	<?php dynamic_sidebar( 'shop' ); ?>

<?php } ?>