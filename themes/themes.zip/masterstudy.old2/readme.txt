Master study readme file


http://stylemixthemes.com
